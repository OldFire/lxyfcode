#ifndef TTCX_JSON_H
#define TTCX_JSON_H
#include<QJsonObject>
#include<QJsonDocument>

class TTCX_Json
{
public:
    TTCX_Json();
    TTCX_Json(const char *inData);
    int setKey(const char* key, const char* value);
    int getKey(const char* key, char **value);
    int print(char **outData, int* size);
    void free(char **dataMem);
public:
   QJsonObject json;
};


#endif // TTCX_JSON_H
