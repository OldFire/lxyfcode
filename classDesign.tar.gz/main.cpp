#include "ttcx_json.h"
#include<QDebug>

int main()
{
    TTCX_Json  ttcx;
    ttcx.setKey("aaa","111");
    ttcx.setKey("bbb","222");
    char*tmp;
    ttcx.getKey("aaa",&tmp);
    ttcx.setKey("aaa","aaa");
    qDebug()<<tmp;

    //ttcx.free(&tmp);



    QJsonDocument document;
    document.setObject(ttcx.json);
    QByteArray byte_array = document.toJson(QJsonDocument::Compact);
    qDebug()<<byte_array;
    QString json_str(byte_array);
    qDebug()<<json_str;
}
