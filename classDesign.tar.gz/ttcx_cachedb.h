#ifndef TTCX_CACHEDB_H
#define TTCX_CACHEDB_H
#include <stdio.h>
#include <string>
#include <stdlib.h>
#include <stddef.h>
#include <stdarg.h>
#include <string.h>
#include <assert.h>
#include "hiredis.h"
#include "ttcx_json.h"
#include <time.h>
#include<vector>
#include <algorithm>
#include <string>
using namespace std;


class TTCX_CacheDb
{
public:
    TTCX_CacheDb();
    int open(const char* ip, const char* port);
    void close();
    int setObj(const char*inData);
    int getObj(char**outData,int *outlen,const char*inData,const char*order);
    int backEqualdriver(const char*geohash,char**outData,int *outlen);

    int setlocalinfo(TTCX_Json&);
    int setorderinfo(TTCX_Json&);

    int getlocalinfo(TTCX_Json&,const char*inData);
    int getorderinfo(TTCX_Json&,const char*inData);

    void findsecond(vector<pair<string,string>>&tmp,const char*geohash,char**outData,int *outlen);
public:
    redisContext* c;
    vector<pair<string,string>>geovec;

};

#endif // TTCX_CACHEDB_H
