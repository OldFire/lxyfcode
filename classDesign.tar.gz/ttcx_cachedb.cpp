#include "ttcx_cachedb.h"

TTCX_Json req_driver;
typedef pair<string,string> PAIR;

bool cmp(const PAIR& x,const PAIR& y)
{
    return atoll(x.second.c_str()) <atoll(y.second.c_str());
}

TTCX_CacheDb::TTCX_CacheDb()
{

}

int TTCX_CacheDb::open(const char *ip, const char* port)
{
    //redis默认监听端口为6387，可以在配置文件中修改
    c = redisConnect(ip, atoi(port));
    if ( c->err)
    {
        redisFree(c);
        printf("Connect to redisServer faile\n");
        return -1;
    }
    return 1;
}

void TTCX_CacheDb::close()
{
    redisFree(c);
}

int TTCX_CacheDb::setObj(const char*inData)
{

    TTCX_Json msgreq(inData);
    char *cmd;
    msgreq.getKey("cmd",&cmd);

    if(strcmp(cmd,"updatepos")==0)
    {
        return setlocalinfo(msgreq);
    }
    if(strcmp(cmd,"reqorder")==0)
    {
        return setorderinfo(msgreq);
    }
    else
    {
        printf("can't recognize the msgreq");
        return -1;
    }

}

int TTCX_CacheDb::getObj(char **outData,int *outlen,const char*inData,const char*cmd)
{
    //const char* command3 = "get key1";

    TTCX_Json msg_res;
    if(memcmp(cmd,"updatepos",9)==0)
    {
         getlocalinfo(msg_res,inData);
    }
    else if(memcmp(cmd,"reqorder",8)==0)
    {
         getorderinfo(msg_res,inData);
    }
    else
    {
        printf("can't recognize the msgreq");
        return -1;
    }


    msg_res.print(outData,outlen);
    return 1;

}

int TTCX_CacheDb::backEqualdriver(const char *geohash,char**outData,int *outlen)
{
    redisReply*r = (redisReply*)redisCommand(c, "smembers %s","name_hash_set");
    if ( r->type != REDIS_REPLY_ARRAY)
    {
        printf("Failed to execute command %s\n","getobj");
        freeReplyObject(r);
        redisFree(c);
        return -1;
    }
    char keybuf[1024]={0};
    char valbuf[1024]={0};
    for (unsigned int j = 0; j < r->elements; j++) {
       sscanf(r->element[j]->str,"%[^|]|%s",keybuf,valbuf);
       geovec.push_back(make_pair(keybuf,valbuf));
            }
   sort(geovec.begin(),geovec.end(),cmp);

   vector<pair<string,string>>tmp(geovec);

    findsecond(tmp,geohash,outData,outlen);

    return 1;
}


int TTCX_CacheDb::setlocalinfo(TTCX_Json&msgreq)
{
    char *cmd;
    msgreq.getKey("cmd",&cmd);

    char *session;
    msgreq.getKey("session",&session);

    char *username;
    msgreq.getKey("username",&username);

    char *type;
    msgreq.getKey("type",&type);

    char *latitude;
    msgreq.getKey("latitude",&latitude );

    char *longitude;
    msgreq.getKey("longitude",&longitude);

    char *geohash ;
    msgreq.getKey("geohash",&geohash);

    char curtime[64]={0};
    time_t t = time(0);
    strftime( curtime, sizeof(curtime), "%Y-%m-%d|%H:%M:%S",localtime(&t));





    char buf[4096]={0};
    //const char* command1 = "hmset myhash field1 Hello field2 World";
    sprintf(buf,"hmset %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",username,
            "cmd",cmd,"session",session,"username",username,"type",type,"latitude",latitude,
            "longitude",longitude,"geohash",geohash,"curtime",curtime);

    char command2[1024]={0};
    sprintf(command2,"EXPIRE %s %d",username,900);

    msgreq.free(&cmd);
    msgreq.free(&session);
    msgreq.free(&type);
    msgreq.free(&latitude);
    msgreq.free(&longitude);


    const char* command1 = buf;
    redisReply* r = (redisReply*)redisCommand(c, command1);
    if( NULL == r) {
        printf("Execut command1 failure\n");
        redisFree(c);
        return -1;
    }
    if( !(r->type == REDIS_REPLY_STATUS && strcasecmp(r->str,"OK")==0)) {
        printf("Failed to execute command[%s]\n",command1);
        freeReplyObject(r);
        redisFree(c);
        return -1;
    }


    r = (redisReply*)redisCommand(c, command2);
    freeReplyObject(r);



    r = (redisReply*)redisCommand(c,  "sadd name_hash_set %s|%s",username,geohash);
    freeReplyObject(r);


    r = (redisReply*)redisCommand(c, "EXPIRE %s %d","name_hash_set",900);
    freeReplyObject(r);


   msgreq.free(&geohash);
   msgreq.free(&username);


    return 1;
}

int TTCX_CacheDb::setorderinfo(TTCX_Json &msgreq)
{
    char *cmd;
    msgreq.getKey("cmd",&cmd);

    char *session;
    msgreq.getKey("session",&session);

    char *passengername;
    msgreq.getKey("passengername",&passengername);

    char *drivername;
    msgreq.getKey("drivername",&drivername);

    char *order;
    msgreq.getKey("order",&order);

    char *state;
    msgreq.getKey("state",&state);

    char curtime[64]={0};
    time_t t = time(0);
    strftime( curtime, sizeof(curtime),"%Y-%m-%d|%H:%M:%S",localtime(&t));

    char buf[4096]={0};
    //const char* command1 = "hmset myhash field1 Hello field2 World";
    sprintf(buf,"hmset %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",order,
            "cmd",cmd,"session",session,"passengername",passengername,
            "drivername",drivername,"order",order,"state",state,"curtime",
            curtime);

    char command2[1024]={0};
    sprintf(command2,"EXPIRE %s %d",order,900);

    msgreq.free(&cmd);
    msgreq.free(&session);
    msgreq.free(&passengername);
    msgreq.free(&drivername);
    msgreq.free(&order);
    msgreq.free(&state);


    const char* command1 = buf;
    redisReply* r = (redisReply*)redisCommand(c, command1);
    if( NULL == r) {
        printf("Execut command1 failure\n");
        redisFree(c);
        return -1;
    }
    if( !(r->type == REDIS_REPLY_STATUS && strcasecmp(r->str,"OK")==0)) {
        printf("Failed to execute command[%s]\n",command1);
        freeReplyObject(r);
        redisFree(c);
        return -1;
    }
    freeReplyObject(r);

   r = (redisReply*)redisCommand(c, command2);

    freeReplyObject(r);

    return 1;
}

int TTCX_CacheDb::getlocalinfo(TTCX_Json &msg_res,const char*inData)
{
    msg_res.setKey("username",inData);

    redisReply*r = (redisReply*)redisCommand(c, "hget %s %s",inData,"latitude");
    if ( r->type != REDIS_REPLY_STRING)
    {
        printf("Failed to execute command %s\n","getobj");
        freeReplyObject(r);
        redisFree(c);
        return -1;
    }
    //printf("The value of 'key1' is %s\n", r->str);
    msg_res.setKey("latitude",r->str);
    freeReplyObject(r);

    r = (redisReply*)redisCommand(c, "hget %s %s",inData,"longitude");
    if ( r->type != REDIS_REPLY_STRING)
    {
        printf("Failed to execute command %s\n","getobj");
        freeReplyObject(r);
        redisFree(c);
        return -1;
    }
    msg_res.setKey("longitude",r->str);
    freeReplyObject(r);

    r = (redisReply*)redisCommand(c, "hget %s %s",inData,"curtime");
    if ( r->type != REDIS_REPLY_STRING)
    {
        printf("Failed to execute command %s\n","getobj");
        freeReplyObject(r);
        redisFree(c);
        return -1;
    }
    msg_res.setKey("curtime",r->str);
    freeReplyObject(r);

    r = (redisReply*)redisCommand(c, "hget %s %s",inData,"geohash");
    if ( r->type != REDIS_REPLY_STRING)
    {
        printf("Failed to execute command %s\n","getobj");
        freeReplyObject(r);
        redisFree(c);
        return -1;
    }
    msg_res.setKey("geohash",r->str);
    freeReplyObject(r);

    return 1;
}

int TTCX_CacheDb::getorderinfo(TTCX_Json &msg_res,const char*inData)
{
    msg_res.setKey("order",inData);

    redisReply*r = (redisReply*)redisCommand(c, "hget %s %s",inData,"passengername");
    if ( r->type != REDIS_REPLY_STRING)
    {
        printf("Failed to execute command %s\n","getobj");
        freeReplyObject(r);
        redisFree(c);
        return -1;
    }
    //printf("The value of 'key1' is %s\n", r->str);
    msg_res.setKey("passengername",r->str);
    freeReplyObject(r);

    r = (redisReply*)redisCommand(c, "hget %s %s",inData,"drivername");
    if ( r->type != REDIS_REPLY_STRING)
    {
        printf("Failed to execute command %s\n","getobj");
        freeReplyObject(r);
        redisFree(c);
        return -1;
    }
    msg_res.setKey("drivername",r->str);
    freeReplyObject(r);

    r = (redisReply*)redisCommand(c, "hget %s %s",inData,"curtime");
    if ( r->type != REDIS_REPLY_STRING)
    {
        printf("Failed to execute command %s\n","getobj");
        freeReplyObject(r);
        redisFree(c);
        return -1;
    }
    msg_res.setKey("curtime",r->str);
    freeReplyObject(r);

    r = (redisReply*)redisCommand(c, "hget %s %s",inData,"state");
    if ( r->type != REDIS_REPLY_STRING)
    {
        printf("Failed to execute command %s\n","getobj");
        freeReplyObject(r);
        redisFree(c);
        return -1;
    }
    msg_res.setKey("state",r->str);
    freeReplyObject(r);

    return 1;
}



void TTCX_CacheDb::findsecond(vector<pair<string,string>>&tmp,const char *geohash,char**outData,int *outlen)
{
    vector<pair<string,string>>::iterator div2it;
    int i=tmp.size();//the nubmer of user

    int j=0;
    long long int div1,div2,div3;
    div1=div2=div3=0;

    for(auto it=tmp.begin();it!=tmp.end();it++,j++)
    {
        if(int(i/4)==j)
        {
            div1=abs(atoll((it->second).c_str())-atoll(geohash));

        }

        if(int(i/2)==j)
        {
           div2=abs(atoll((it->second).c_str())-atoll(geohash));
           div2it=it;

        }
        if(int(i*3/4)==j)
        {
           div3=abs(atoll((it->second).c_str())-atoll(geohash));

          // printf("div1=%lld,div2=%lld,div3=%lld\n",div1,div2,div3);

           if(div2<=div1&&div2<=div3)
           {
               req_driver.setKey((div2it->first).c_str(),(div2it->second).c_str());

               req_driver.print(outData,outlen);
               //printf("mingeohash=%s",(div2it->second).c_str());
               return;
           }
           if(div1<=div2)
           {
               tmp.erase(div2it,tmp.end());
               break;
           }
           if(div3<=div2)
           {
               tmp.erase(tmp.begin(),div2it);
               break;
           }

           break;
        }

    }

    //printf("tmpsize=%d",tmp.size());
    findsecond(tmp,geohash,outData,outlen);
}


