#include "ttcx_json.h"
TTCX_Json::TTCX_Json()
{
}

TTCX_Json::TTCX_Json(const char*inData)
{
   QByteArray arry;
   arry.append(inData);
   QJsonDocument doc=QJsonDocument::fromJson(arry);
   json=doc.object();
}

int TTCX_Json::setKey(const char *key, const char *value)
{
    json.insert(key,QString(value));
    return 1;
}

int TTCX_Json::getKey(const char *key, char **value)
{
    QJsonValue val=json.value(key);

    const char*tmp=val.toString().toStdString().c_str();//QJsonValue->QString->string->char*;
    *value=(char*)calloc(1024,1);
    memcpy(*value,tmp,strlen(tmp)+1);
    return 1;
}

int TTCX_Json::print(char **outData, int *size)
{
    *outData=(char*)calloc(4096,1);
    QJsonDocument doc;
    doc.setObject(json);
    QByteArray arry=doc.toJson(QJsonDocument::Compact);
    memcpy(*outData,arry.data(),arry.length());
    *size=arry.length();
    return 1;
}

void TTCX_Json::free(char **dataMem)
{
    ::free(*dataMem);//表示全局的free函数
    *dataMem=NULL;
}
